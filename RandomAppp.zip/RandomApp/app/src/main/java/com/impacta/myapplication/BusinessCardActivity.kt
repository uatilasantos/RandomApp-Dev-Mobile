package com.impacta.myapplication

import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

class BusinessCardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_final)

        val btVoltar4: ImageButton = findViewById(R.id.btVoltar4)
        btVoltar4.setOnClickListener {
            finish()
        }
    }
}